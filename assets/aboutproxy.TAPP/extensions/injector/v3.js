// TODO: MV3 injecting
class ExtensionInjectorMV3 extends ExtensionInjector {
  constructor(){super()}
  parseManifest(){}
  async injectDOMContentLoaded(){}
  async injectLoaded(){}
}
