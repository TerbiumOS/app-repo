# The almondLAN Player
This is the very basic build of the player built for almondLAN `v.1.3`