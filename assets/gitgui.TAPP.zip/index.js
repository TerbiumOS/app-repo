const repoContainer = document.querySelector('.repo')
const changesContainer = document.querySelector('.changes')
const commitContainer = document.querySelector('.commit')
const commitbtn = document.querySelector('#commit-btn')

document.addEventListener("DOMContentLoaded", () => {
    const repoInp = document.querySelector('#git-inp')
    const askDiag = document.querySelector('#ask-diag')
    if (localStorage.getItem('gitguiRepo')) {
        repoInp.value = `${localStorage.getItem('gitguiRepo')}/.git/`
        askDiag.classList.remove('hidden')
        load(localStorage.getItem('gitguiRepo'))
    } else {
        askDiag.classList.remove('hidden')
    }
    commitbtn.addEventListener('click', () => {
        if (commitbtn.innerText === 'Sync') {
            sync()
        } else {
            commit()
        }
    })
})

onload = () => {
    window.tb ? document.body.dataset.tb = true : document.body.dataset.tb = false
    let commitAndRepoHeight = repoContainer.getClientRects()[0].height + commitContainer.getClientRects()[0].height
    changesContainer.style.setProperty('--changes-height', `calc(100% - calc(${commitAndRepoHeight}px) - calc(var(--gaps) * 2))`)
}

async function commit() {
    const commitInp = document.querySelector('#commit-inp')
    if (!commitInp.value) {
        throw new Error('You need to provide a commit message to continue')
    }
    const Filer = window.parent.Filer
    const repoDir = localStorage.getItem('gitguiRepo')
    try {
        commitbtn.disabled = true
        await Filer.fs.promises.stat(repoDir)
        const statusMatrix = await git.statusMatrix({ fs: Filer.fs, dir: repoDir })
        console.log(statusMatrix)
        for (const [filepath, , , workingDir] of statusMatrix) {
            console.log(`Adding file: ${filepath}`)
            await git.add({ fs: Filer.fs, dir: repoDir, filepath })
        }
        await git.commit({
            fs: Filer.fs,
            dir: repoDir,
            message: commitInp.value
        })
        const log = await git.log({ fs: Filer.fs, dir: repoDir })
        console.log('Commit log:', log)
        commitbtn.innerText = 'Sync'
        commitbtn.disabled = false
        changesContainer.innerHTML = ''
    } catch (err) {
        console.error('Error during commit:', err)
        commitbtn.disabled = false
    }
}

async function sync() {
    await git.pull({
        fs: window.parent.Filer.fs,
        http: window.http,
        dir: localStorage.getItem('gitguiRepo'),
        singleBranch: true,
        onMessage: (e) => {
            console.log(e)
        },
        onAuth: async () => {
            return new Promise(async (resolve) => {
                if (!window.parent.Filer.fs.exists('//apps/system/gitgui.tapp/cache.TCACHE')) {
                    await window.parent.tb.dialog.WebAuth({
                        title: "GitHub Authentication",
                        onOk: async ({ username, password }) => {
                            const data = `${username}:${password}`;
                            await window.parent.Filer.fs.promises.writeFile('//apps/system/gitgui.tapp/cache.TCACHE', data);
                            resolve({ username, password })
                        },
                        onCancel: () => {
                            throw new Error('Authentication was canceled')
                        }
                    })
                } else {
                    const data = await window.parent.Filer.fs.promises.readFile('//apps/system/gitgui.tapp/cache.TCACHE', 'utf8')
                    // TODO: Add encryption
                    const [username, password] = data.split(':')
                    resolve({ username, password })
                }
            })
        },
    })
    await git.push({
        fs: window.parent.Filer.fs,
        http: window.http,
        dir: localStorage.getItem('gitguiRepo'),
        singleBranch: true,
        onAuth: async () => {
            return new Promise(async (resolve) => {
                if (!window.parent.Filer.fs.exists('//apps/system/gitgui.tapp/cache.TCACHE')) {
                    await window.parent.tb.dialog.WebAuth({
                        title: "GitHub Authentication",
                        onOk: async ({ username, password }) => {
                            const data = `${username}:${password}`;
                            await window.parent.Filer.fs.promises.writeFile('//apps/system/gitgui.tapp/cache.TCACHE', data);
                            resolve({ username, password })
                        },
                        onCancel: () => {
                            throw new Error('Authentication was canceled')
                        }
                    })
                } else {
                    const data = await window.parent.Filer.fs.promises.readFile('//apps/system/gitgui.tapp/cache.TCACHE', 'utf8')
                    // TODO: Add encryption
                    const [username, password] = data.split(':')
                    resolve({ username, password })
                }
            })
        },
        onMessage: (e) => {
            console.log(e)
        }
    })
    commitbtn.innerText = `Commit`
}

function clone() {
    window.parent.tb.dialog.Message({
        title: "Enter a repository to clone",
        onOk: async (val) => {
            sessionStorage.setItem('CloneLoc', val)
            window.parent.tb.dialog.DirectoryBrowser({
                title: "Select a Folder to Open",
                onOk: async (val) => {
                    localStorage.setItem('gitguiRepo', val)
                    await git.setConfig({
                        fs: window.parent.Filer.fs,
                        dir: val,
                        path: 'user.name',
                        value: await window.parent.tb.user.username()
                    })
                    const title = document.querySelector('#diag-title')
                    const desc = document.querySelector('#diag-txt')
                    const askDiag = document.querySelector('#ask-diag')
                    if (askDiag.classList.contains('hidden')) {
                        askDiag.classList.remove('hidden')
                    }
                    title.innerText = "Cloning..."
                    desc.innerText = "Your repo is being cloned please wait..."
                    await window.git.clone({
                        fs: window.parent.Filer.fs,
                        http: window.http,
                        dir: val,
                        corsProxy: 'https://cors.isomorphic-git.org',
                        url: sessionStorage.getItem('CloneLoc'),
                        noCheckout: false,
                        singleBranch: true,
                        depth: 1,
                        onAuth: async () => {
                            return new Promise(async (resolve) => {
                                if (!window.parent.Filer.fs.exists('//apps/system/gitgui.tapp/cache.TCACHE')) {
                                    await window.parent.tb.dialog.WebAuth({
                                        title: "GitHub Authentication",
                                        onOk: async ({ username, password }) => {
                                            const data = `${username}:${password}`;
                                            await window.parent.Filer.fs.promises.writeFile('//apps/system/gitgui.tapp/cache.TCACHE', data);
                                            resolve({ username, password })
                                        },
                                        onCancel: () => {
                                            throw new Error('Authentication was canceled')
                                        }
                                    })
                                } else {
                                    const data = await window.parent.Filer.fs.promises.readFile('//apps/system/gitgui.tapp/cache.TCACHE', 'utf8')
                                    // TODO: Add encryption
                                    const [username, password] = data.split(':')
                                    resolve({ username, password })
                                }
                            })
                        },
                        onMessage: (e) => {
                            console.log(e)
                        }
                    })
                    load(val)
                }
            })
        }
    })
}

async function load(repo) {
    const askDiag = document.querySelector('#ask-diag')
    if (!askDiag.classList.contains('hidden')) {
        askDiag.classList.add('hidden')
    }
    const Filer = window.parent.Filer
    try {
        await Filer.fs.promises.stat(`${repo}/.git`)
    } catch (err) {
        throw new Error(`No Git folder found. ${err}`)
    }
    const files = await Filer.fs.promises.readdir(repo)
    const statusEntries = []
    for (const file of files) {
        const filePath = `${repo}/${file}`
        let stats
        try {
            stats = await Filer.fs.promises.stat(filePath)
        } catch (err) {
            console.error('Error getting file stats:', err)
            continue
        }
        if (stats.isDirectory()) {
            continue
        }
        let fileStatus
        try {
            fileStatus = await git.status({
                fs: Filer.fs,
                dir: repo,
                filepath: file
            })
        } catch (err) {
            console.error('Error getting git status for file:', err)
            continue
        }
        let statusLabel = ''
        switch (fileStatus) {
            case 'modified':
                statusLabel = 'M'
                break
            case 'deleted':
                statusLabel = 'D'
                break
            case 'added':
                statusLabel = 'A'
                break
            case '*modified':
                statusLabel = 'M'
                break
            case '*deleted':
                statusLabel = 'D'
                break
            case '*added':
                statusLabel = 'A'
                break
            case 'ignored':
            case 'unmodified':
            case 'absent':
            case 'undeleted':
            case 'undeletemodified':
                continue
            default:
                console.warn(`Unhandled status: ${fileStatus}`)
                continue
        }
        statusEntries.push(createFileEntry(file, statusLabel))
    }
    changesContainer.innerHTML = ''
    statusEntries.forEach(entry => changesContainer.appendChild(entry))
    if (files.includes('README.md')) {
        try {
            const readme = await Filer.fs.promises.readFile(`${repo}/README.md`, 'utf8')
            const filePrev = document.querySelector('#file-prev')
            if (filePrev) {
                setOpenFile(`${repo}/README.md`)
                filePrev.value = readme
            }
        } catch (err) {
            console.error('Error reading README.md:', err)
        }
    }
}

function createFileEntry(file, status) {
    const fileDiv = document.createElement('div')
    fileDiv.className = 'changed-file'
    const icon = document.createElement('img')
    icon.src = 'icon.svg'
    icon.alt = 'File Icon'
    icon.className = 'file-icon'
    fileDiv.appendChild(icon)
    const fileName = document.createElement('span')
    fileName.textContent = file
    fileName.className = 'file-name'
    fileDiv.appendChild(fileName)
    const statusSpan = document.createElement('span')
    statusSpan.textContent = status
    statusSpan.className = 'file-status'
    fileDiv.appendChild(statusSpan)
    const act = async () => {
        const val = document.querySelector('#git-inp').value
        const repo = val.replace('/.git/', '')
        const readme = await window.parent.Filer.fs.promises.readFile(`${repo}/${file}`, 'utf8')
        const filePrev = document.querySelector('#file-prev')
        if (filePrev) {
            setOpenFile(`${repo}/${file}`)
            filePrev.value = readme
        }
    }
    fileDiv.addEventListener('click', act)
    fileName.addEventListener('click', act)
    return fileDiv
}

function setOpenFile(file) {
    const topbar = document.querySelector('#topbar')
    const dv = document.createElement('div')
    dv.classList.add('open-file')
    const title = document.createElement('h3')
    title.innerText = file
    const btn = document.createElement('button')
    btn.classList.add('file-status')
    btn.style.height = '21px'
    btn.style.padding = '4px 12px'
    btn.innerText = 'X'
    btn.addEventListener('click', () => {
        topbar.innerHTML = ``
        const filePrev = document.querySelector('#file-prev')
        filePrev.value = ``
    })
    dv.appendChild(title)
    dv.appendChild(btn)
    dv.addEventListener('click', async () => {
        const file = await window.parent.Filer.fs.promises.readFile(`${title.innerText}`, 'utf8')
        const filePrev = document.querySelector('#file-prev')
        console.log(`${title.innerText}`)
        if (filePrev) {
            filePrev.value = file
        }
    })
    topbar.innerHTML = ``
    topbar.appendChild(dv)
}

function openPath() {
    window.parent.tb.dialog.DirectoryBrowser({
        title: "Select a Folder to Open",
        onOk: async (val) => {
            localStorage.setItem('gitguiRepo', val)
            await git.setConfig({
                fs: window.parent.Filer.fs,
                dir: val,
                path: 'user.name',
                value: await window.parent.tb.user.username()
            })
            load(val)
        }
    })
}

function opt() {
    const rect = document.getElementById('opt').getBoundingClientRect()
    const xax = rect.left
    const yax = rect.bottom + 10
    window.parent.tb.contextmenu.create({
        x: xax,
        y: yax,
        options: [
            {
                text: "Pull",
                click: async () => {
                    await git.pull({
                        fs: window.parent.Filer.fs,
                        http: window.http,
                        dir: localStorage.getItem('gitguiRepo'),
                        singleBranch: true,
                        onMessage: (e) => {
                            console.log(e)
                        },
                        onAuth: async () => {
                            return new Promise(async (resolve) => {
                                if (!window.parent.Filer.fs.exists('//apps/system/gitgui.tapp/cache.TCACHE')) {
                                    await window.parent.tb.dialog.WebAuth({
                                        title: "GitHub Authentication",
                                        onOk: async ({ username, password }) => {
                                            const data = `${username}:${password}`;
                                            await window.parent.Filer.fs.promises.writeFile('//apps/system/gitgui.tapp/cache.TCACHE', data);
                                            resolve({ username, password })
                                        },
                                        onCancel: () => {
                                            throw new Error('Authentication was canceled')
                                        }
                                    })
                                } else {
                                    const data = await window.parent.Filer.fs.promises.readFile('//apps/system/gitgui.tapp/cache.TCACHE', 'utf8')
                                    // TODO: Add encryption
                                    const [username, password] = data.split(':')
                                    resolve({ username, password })
                                }
                            })
                        },
                    })
                }
            },
            {
                text: "Push",
                click: async () => {
                    await git.push({
                        fs: window.parent.Filer.fs,
                        http: window.http,
                        dir: localStorage.getItem('gitguiRepo'),
                        singleBranch: true,
                        onMessage: (e) => {
                            console.log(e)
                        }
                    })
                }
            },
            {
                text: "Checkout",
                click: async () => {
                    alert('test')
                }
            },
            {
                text: "Fetch",
                click: async () => {
                    await git.fetch({
                        fs: window.parent.Filer.fs,
                        http: window.http,
                        dir: localStorage.getItem('gitguiRepo'),
                        corsProxy: 'https://cors.isomorphic-git.org',
                        url: 'https://github.com/isomorphic-git/isomorphic-git',
                        depth: 1,
                        singleBranch: true,
                        tags: false,
                        onMessage: (e) => {
                            console.log(e)
                        }
                    })
                }
            },
            {
                text: "Branch",
                click: async () => {
                    alert('test')
                }
            },
            {
                text: "Remote",
                click: async () => {
                    alert('test')
                }
            }
        ]
    })
}