const upd = async () => {
    const userMessage = document.getElementById('user-input');
    userMessage.disabled = true;
    document.querySelector('button').disabled = true;
    const chatBox = document.getElementById('chat-box');
    const p = document.createElement('p');
    p.textContent = "Working...";
    chatBox.appendChild(p);
    const res = await window.parent.tb.libcurl.fetch('https://ai.hackclub.com/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            messages: [
                { role: 'user', content: userMessage.value }
            ]
        })
    });
    const { choices } = await res.json();
    const aiReply = choices?.[0]?.message?.content?.trim() || 'No response';
    p.textContent = aiReply;
    document.querySelector('button').disabled = false;
    chatBox.scrollTop = chatBox.scrollHeight;
    userMessage.disabled = false;
    userMessage.value = '';
}
document.querySelector('button').addEventListener('click', upd);
document.querySelector('input').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        upd();
    }
})